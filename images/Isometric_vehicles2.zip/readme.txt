This pack contains 12 spritesheets with all the cars in 1 color
there are 12 colors available.
thats a total 144 different vehicles in this pack.
rotated 16ways with increment of 22.5 degrees for fluid animations.


Color:
-----------------------
blackblue_lightblue_midgreengrey_lightgrey_midorangepinkredvioletwhiteyellow

resolution per vehicle
------------------------
64x64 pixels


view:
------------------------
Isometric view


Spritesheet info
------------------------
every line in the spritesheet has a car with 16 frames for its rotation.
The first frame of every car is facing south or pointing to the bottom left. every following frame is a rotation 22.5 degrees clockwise.

